package com.example.mathtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main5Activity extends AppCompatActivity {
    TextView textViewResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Intent intent2=getIntent();
        int result=intent2.getIntExtra("max",0);
        int record=intent2.getIntExtra("record",0);
        String score= String.format("Youre score %s\n Max score %s", result,record);
        textViewResult=findViewById(R.id.textViewMax);
        textViewResult.setText(score);


    }

    public void restart1(View view) {
        Intent intent2= new Intent(this,Main4Activity.class);
        startActivity(intent2);
    }

    public void menu1(View view) {
        Intent intent=new Intent(this,Main3Activity.class);
        startActivity(intent);
    }
}
